package com.kelompok3.junit;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class LuasPersegiPanjangTest {
    //LuasPersegiPanjangTest adalah kelas uji unit.
// Ini adalah kelas yang digunakan untuk menguji metode dalam kelas LuasPersegiPanjang.

    private LuasPersegiPanjang luasPersegiPanjang = new LuasPersegiPanjang();
    //private LuasPersegiPanjang luasPersegiPanjang = new LuasPersegiPanjang();
// adalah deklarasi dan inisialisasi objek LuasPersegiPanjang. Objek ini digunakan untuk memanggil metode yang akan diuji.
    @Test
    //@Test adalah anotasi yang digunakan oleh JUnit untuk menandai bahwa metode testAddSucces adalah metode uji unit.
    // Metode yang diberi anotasi @Test akan dijalankan oleh JUnit saat tes unit dijalankan.

    public void testAddSucces() {

        int result = luasPersegiPanjang.add(10, 90);
        //int result = luasPersegiPanjang.add(10, 90);,
        // memanggil metode add dari objek luasPersegiPanjang dengan argumen 10 dan 90,
        // dan hasilnya disimpan dalam variabel result.

        assertEquals(100,result);
        //assertEquals(100, result);, membandingkan hasil yang diharapkan (100) dengan nilai yang sebenarnya
        // (disimpan dalam variabel result). Jika nilai yang diharapkan dan nilai yang sebenarnya tidak cocok,
        // tes unit akan gagal, dan JUnit akan menghasilkan pesan kesalahan.
    }
}