package com.kelompok3.junit;

public class LuasPersegiPanjang {

    public Integer add(Integer panjang, Integer lebar) {return panjang + lebar;}
    //Ini adalah metode sederhana yang menerima dua parameter Integer, yaitu panjang dan lebar,
    // dan mengembalikan hasil penjumlahan dari kedua parameter tersebut. Dalam kasus ini,
    // metode add digunakan untuk menghitung jumlah dari dua bilangan bulat (panjang dan lebar) dan
    // mengembalikan hasilnya dalam bentuk Integer.

    //Misalnya, jika Anda memanggil metode add(10, 5), itu akan mengembalikan hasil 15, karena 10 + 5 adalah 15.
    //Metode ini relatif sederhana dan hanya melakukan operasi penjumlahan.
}
